function printTriangle(a){
   var i = 0;
   for (i = 1; i <= a; i++){
       console.log("* ".repeat(i));
   }
}
printTriangle(4);